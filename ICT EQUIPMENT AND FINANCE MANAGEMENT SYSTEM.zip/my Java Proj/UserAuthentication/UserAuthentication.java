import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UserAuthentication {
    private Map<String, String> users = new HashMap<>();

    public UserAuthentication(String filename) {
        loadUsers(filename);
    }

    private void loadUsers(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String password = parts[1].trim();
                    users.put(username, password);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    public static void main(String[] args) {
        UserAuthentication auth = new UserAuthentication("users.txt");
        
        // Inside main method:
        try (Scanner input = new Scanner(System.in)) {
            System.out.print("Enter username: ");
            String username = input.nextLine();

            System.out.print("Enter password: ");
            String password = input.nextLine();
     
            if (auth.authenticate(username, password)) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Login failed!");
            }
        }
    }
}
