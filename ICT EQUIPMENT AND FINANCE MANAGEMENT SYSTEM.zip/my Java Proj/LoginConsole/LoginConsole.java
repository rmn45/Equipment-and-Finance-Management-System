import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class LoginConsole {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("====== ICT SYSTEM LOGIN ======");
        System.out.print("Enter Username: ");
        String enteredUsername = input.nextLine();

        System.out.print("Enter Password: ");
        String enteredPassword = input.nextLine();

        boolean isAuthenticated = checkCredentials(enteredUsername, enteredPassword);

        if (isAuthenticated) {
            System.out.println("Login Successful! Welcome " + enteredUsername);
            showMainMenu(); // ✅ Calls the main menu after login
        } else {
            System.out.println("Invalid username or password.");
        }
        input.close();
    }

    public static boolean checkCredentials(String username, String password) {
        File file = new File("users.txt");
        try (Scanner fileScanner = new Scanner(file)) {

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(",");

                if (parts.length == 2) {
                    String storedUser = parts[0];
                    String storedPass = parts[1];

                    if (storedUser.equals(username) && storedPass.equals(password)) {
                        return true;
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("User file not found.");
        }

        return false;
    }

    public static void showMainMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Manage ICT Equipment");
            System.out.println("2. Manage Finances");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    ICTEquipmentModule.equipmentMenu();
                    break;
                case 2:
                    FinanceModule.financeMenu();
                    break;
                    case 3:
                    System.out.println("Exiting the system.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 3);
        scanner.close();
    }

} // ✅ THIS IS THE CLOSING OF THE CLASS — MAKE SURE IT'S LAST!

