import java.io.*;
import java.util.*;

public class FinanceModule {
    public static void financeMenu() {
        Scanner input = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Finance Tracker Menu ---");
            System.out.println("1. Add Finance Record");
            System.out.println("2. View Records");
            System.out.println("3. Delete Record");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addRecord(input);
                    break;
                case 2:
                    viewRecords();
                    break;
                case 3:
                    deleteRecord(input);
                    break;
                case 4:
                    System.out.println("Returning to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 4);
    }

    private static void addRecord(Scanner input) {
        try {
            FileWriter fw = new FileWriter("finance.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);

            System.out.print("Enter Date (YYYY-MM-DD): ");
            String date = input.nextLine();
            System.out.print("Enter Description: ");
            String description = input.nextLine();
            System.out.print("Enter Amount: ");
            String amount = input.nextLine();

            out.println(date + "," + description + "," + amount);
            out.close();
            System.out.println("Finance record added successfully.");

        } catch (IOException e) {
            System.out.println("Error writing to finance file.");
        }
    }

    private static void viewRecords() {
    System.out.println("\n--- Finance Records ---");

    try {
        File file = new File("finance.txt");
        Scanner fileScanner = new Scanner(file);

        boolean hasRecords = false;  // This will help us detect if there's any data

        while (fileScanner.hasNextLine()) {
            String line = fileScanner.nextLine();
            String[] parts = line.split(",");

            if (parts.length == 3) {
                String date = parts[0];
                String description = parts[1];
                String amount = parts[2];

                System.out.println("Date: " + date + ", Description: " + description + ", Amount: " + amount);
                hasRecords = true;
            }
        }

        if (!hasRecords) {
            System.out.println("No finance records found.");
        }

        fileScanner.close();
    } catch (FileNotFoundException e) {
        System.out.println("Finance file not found.");
    }
}


    private static void deleteRecord(Scanner input) {
        try {
            File inputFile = new File("finance.txt");
            if (!inputFile.exists()) {
                System.out.println("No finance records found.");
                return;
            }

            List<String> lines = new ArrayList<>();
            Scanner fileScanner = new Scanner(inputFile);
            while (fileScanner.hasNextLine()) {
                lines.add(fileScanner.nextLine());
            }
            fileScanner.close();

            System.out.print("Enter Date of the record to delete: ");
            String dateToDelete = input.nextLine();

            boolean found = false;
            Iterator<String> iterator = lines.iterator();
            while (iterator.hasNext()) {
                String line = iterator.next();
                if (line.startsWith(dateToDelete + ",")) {
                    iterator.remove();
                    found = true;
                }
            }

            if (found) {
                PrintWriter writer = new PrintWriter(new FileWriter("finance.txt"));
                for (String line : lines) {
                    writer.println(line);
                }
                writer.close();
                System.out.println("Record deleted.");
            } else {
                System.out.println("Record not found.");
            }

        } catch (IOException e) {
            System.out.println("Error deleting record.");
        }
    }
}
