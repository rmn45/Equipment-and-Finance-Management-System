import java.io.*;
import java.util.Scanner;

public class ICTEquipmentModule {

    private static final String FILE_NAME = "equipment.txt";

    public static void equipmentMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- ICT Equipment Menu ---");
            System.out.println("1. Add Equipment");
            System.out.println("2. View Equipment");
            System.out.println("3. Delete Equipment");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    addEquipment(scanner);
                    break;
                case 2:
                    viewEquipment();
                    break;
                case 3:
                    deleteEquipment(scanner);
                    break;
                case 4:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 4);
    }

    private static void addEquipment(Scanner scanner) {
        try (FileWriter writer = new FileWriter(FILE_NAME, true)) {
            System.out.print("Enter Equipment Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Serial Number: ");
            String serial = scanner.nextLine();
            System.out.print("Enter Assigned To: ");
            String assigned = scanner.nextLine();

            writer.write(name + "," + serial + "," + assigned + "\n");
            System.out.println("Equipment added successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }
    }

    private static void viewEquipment() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            System.out.println("\n--- Equipment List ---");
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    System.out.println("Name: " + parts[0] + ", Serial: " + parts[1] + ", Assigned To: " + parts[2]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }

    private static void deleteEquipment(Scanner scanner) {
        System.out.print("Enter Serial Number of equipment to delete: ");
        String serialToDelete = scanner.nextLine();

        File inputFile = new File(FILE_NAME);
        File tempFile = new File("temp.txt");

        try (
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            PrintWriter writer = new PrintWriter(new FileWriter(tempFile))
        ) {
            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[1].equals(serialToDelete)) {
                    found = true; // Skip this line (delete)
                } else {
                    writer.println(line);
                }
            }

            if (found) {
                System.out.println("Equipment deleted.");
            } else {
                System.out.println("Equipment not found.");
            }

        } catch (IOException e) {
            System.out.println("Error processing file.");
            return;
        }

        // Replace original file with temp file
        if (!inputFile.delete() || !tempFile.renameTo(inputFile)) {
            System.out.println("Could not update equipment file.");
        }
    }
}
